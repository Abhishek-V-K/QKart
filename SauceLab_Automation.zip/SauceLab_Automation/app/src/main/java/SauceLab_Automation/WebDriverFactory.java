package SauceLab_Automation;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class WebDriverFactory {

    private static WebDriver driver;

    // Private constructor to prevent instantiation
    private WebDriverFactory() {
    }

    // Get WebDriver instance
    public static WebDriver getDriver() throws InterruptedException {
        if (driver == null) {

            ChromeOptions options = new ChromeOptions();

            // Opening chrome in incognito
            options.addArguments("--incognito");
            options.addArguments("--start-maximized");

            driver = new ChromeDriver(options);
        }
        return driver;
    }

    // Quit driver
    public static void quitDriver() {
        if (driver != null) {
            driver.quit();
            driver = null;
        }
    }
}
