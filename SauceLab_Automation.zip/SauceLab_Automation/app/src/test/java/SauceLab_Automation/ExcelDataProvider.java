package SauceLab_Automation;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class ExcelDataProvider {

    public static Map<String, String> getData(String sheetName, int rowNumber) {

        Map<String, String> dataMap = new HashMap<>();
        String excelPath = System.getProperty("user.dir") + "/src/test/resources/Credentials.xlsx";

        try (FileInputStream fis = new FileInputStream(excelPath);
             Workbook workbook = new XSSFWorkbook(fis)) {

            Sheet sheet = workbook.getSheet(sheetName);
            Row headerRow = sheet.getRow(0);
            Row dataRow = sheet.getRow(rowNumber);

            int totalCells = headerRow.getLastCellNum();

            for (int i = 0; i < totalCells; i++) {
                Cell headerCell = headerRow.getCell(i);
                Cell valueCell = dataRow.getCell(i);
                String key = headerCell.getStringCellValue();
                String value = valueCell.getStringCellValue();
                dataMap.put(key, value);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

        return dataMap;
    }
}





