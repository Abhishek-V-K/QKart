package SauceLab_Automation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import java.util.List;

public class ProductPage {

    WebDriver driver;
    double totalPrice = 0;

    public ProductPage(WebDriver driver) {
        this.driver = driver;
    }

    public double addItemsToCart(double minPrice, double maxPrice) {
        // Ensure we are on inventory page
        driver.get("https://www.saucedemo.com/inventory.html");

        List<WebElement> priceBars = driver.findElements(By.xpath("//div[@class='pricebar']"));

        for (WebElement priceBar : priceBars) {
            String priceText = priceBar.findElement(By.xpath("./div")).getText().replace("$", "").trim();
            double price = Double.parseDouble(priceText);

            // Add item if price is in given range
            if (price >= minPrice && price <= maxPrice) {
                totalPrice += price;
                priceBar.findElement(By.xpath("./button")).click();
            }
        }
        return totalPrice;
    }
}
