package SauceLab_Automation;

import java.time.Duration;
import java.util.Map;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.*;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class TestCases {

    private WebDriver driver;
    private static ExtentReports extent;
    private static final String REPORT_PATH = "test-output/ExtentReport.html";
    private ExtentTest test;
    private SoftAssert softAssert = new SoftAssert();
    private static final Logger logger = LoggerFactory.getLogger(TestCases.class);

    @BeforeClass
    public void setup() throws InterruptedException {
        driver = WebDriverFactory.getDriver();
        initializeExtentReport();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));

    }

    private void initializeExtentReport() {
        ExtentSparkReporter sparkReporter = new ExtentSparkReporter(REPORT_PATH);
        sparkReporter.config().setDocumentTitle("Automation Test Report");
        sparkReporter.config().setReportName("Sauce Lab Automation");

        extent = new ExtentReports();
        extent.attachReporter(sparkReporter);
        extent.setSystemInfo("Environment", "QA");
        extent.setSystemInfo("Test Framework", "TestNG");
    }

    @AfterClass
    public void teardown() {
        WebDriverFactory.quitDriver();
        if (extent != null) {
            extent.flush();
        }
    }

    @Test(priority = 1)
    public void testCase01() throws Exception {

        // Create test title in Extent Report
        test = extent.createTest("Test Case 01 - Verify Login and Cart Functionality")
                .assignCategory("Functional Test")
                .assignAuthor("Automation QA");
        Map<String, String> data = ExcelDataProvider.getData("Login_Credential", 1);

        try {
            LoginPage login = new LoginPage(driver);
            ProductPage productPage = new ProductPage(driver);
            CheckoutPage checkoutPage = new CheckoutPage(driver);

            test.info("Navigating to SauceDemo Login Page...");
            login.goToLoginPage();
            test.pass("Navigated to SauceDemo Login Page successfully");

            // Validate URL
            String currentUrl = driver.getCurrentUrl();
            if (currentUrl.contains("saucedemo.com")) {
                test.pass("URL validation passed - " + currentUrl);
                captureScreenshot("pass", test);
            } else {
                test.fail("URL validation failed - " + currentUrl);
                captureScreenshot("fail", test);
            }

            // Enter credentials
            test.info("Entering login credentials...");
            login.enterUsename(data.get("username"));
            login.enterPassword(data.get("password"));
            login.clikOnLogin();
            test.pass("Login credentials entered successfully");
            captureScreenshot("pass", test);

            // Add products (range 10–40)
            test.info("Adding products between $10 and $40...");
            double total_price = productPage.addItemsToCart(10.0, 40.0);
            test.pass("Products added successfully. Total: $" + total_price);
            captureScreenshot("pass", test);

            // Go to checkout
            test.info("Navigating to Checkout Page...");
            checkoutPage.clickOnCart();
            checkoutPage.clickOnCheckOut();
            checkoutPage.enterCheckOutDetails();
            checkoutPage.clickOnContinue();
            double checkoutTotal = checkoutPage.itemTotal();
            checkoutPage.scrollDown();
            test.pass("Checkout Page Loaded. Displayed total: $" + checkoutTotal);
            captureScreenshot("pass", test);

            // Price assertion
            softAssert.assertTrue(total_price == checkoutTotal, "Calculated sum of prices is not equal");
            test.pass("Soft assertion passed - Calculated sum is verified successfully");

            // Add one more set of products (<$10)
            test.info("Adding low-priced products (< $10)...");
            double lowPriceTotal = productPage.addItemsToCart(0, 10.0);
            test.pass("Additional items added successfully. Total: $" + lowPriceTotal);
            captureScreenshot("pass", test);

            // Validate final checkout again
            checkoutPage.clickOnCart();
            checkoutPage.clickOnCheckOut();
            checkoutPage.enterCheckOutDetails();
            checkoutPage.clickOnContinue();
            double finalTotal = checkoutPage.itemTotal();
            checkoutPage.scrollDown();
            test.pass("Final Checkout validation successful. Final Total: $" + finalTotal);
            captureScreenshot("pass", test);

            // Final assertion
            softAssert.assertTrue(finalTotal >= total_price, "Final total should be >= initial total");
            test.pass("Soft assertion passed - Final total verified successfully.");
            softAssert.assertAll();

        } catch (Exception e) {
            test.fail("Exception occurred: " + e.getMessage());
            captureScreenshot("fail", test);
            logger.error("Exception in Test Case 01", e);
            softAssert.fail("Test failed due to exception: " + e.getMessage());
        }
    }

    public void captureScreenshot(String status, ExtentTest test) {
        String base64Screenshot = null;
        try {
            TakesScreenshot ts = (TakesScreenshot) driver;
            base64Screenshot = ts.getScreenshotAs(OutputType.BASE64);

            if (status.equalsIgnoreCase("pass")) {
                test.pass("Step passed successfully",
                        MediaEntityBuilder.createScreenCaptureFromBase64String(base64Screenshot).build());
            } else if (status.equalsIgnoreCase("fail")) {
                test.fail("Step failed",
                        MediaEntityBuilder.createScreenCaptureFromBase64String(base64Screenshot).build());
            }
        } catch (Exception e) {
            test.info("Exception while capturing screenshot: " + e.getMessage());
        }
    }

}