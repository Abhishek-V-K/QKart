package SauceLab_Automation;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class CheckoutPage {

    WebDriver driver;

    public CheckoutPage(WebDriver driver){
        this.driver = driver;
    }

    public void clickOnCart(){

        driver.findElement(By.id("shopping_cart_container")).click();
    }

    public void clickOnCheckOut(){
        driver.findElement(By.xpath("//button[@id='checkout']")).click();
    }

    public void enterCheckOutDetails(){
        driver.findElement(By.xpath("//input[@placeholder='First Name']")).sendKeys("Test First Name");
        driver.findElement(By.xpath("//input[@placeholder='Last Name']")).sendKeys("Test Last Name");
        driver.findElement(By.xpath("//input[@placeholder='Zip/Postal Code']")).sendKeys("10001");
    }

    public void clickOnContinue(){
        driver.findElement(By.id("continue")).click();
    }

    public double itemTotal(){
       String totalPrice = driver.findElement(By.xpath("//div[@class='summary_subtotal_label']")).getText();
        // Extract only numeric part using regex
        String num = totalPrice.replaceAll("[^0-9.]", "");

        return Double.parseDouble(num);
    }

    public void scrollDown(){
        WebElement element = driver.findElement(By.xpath("//button[@id='finish']"));
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].scrollIntoView(true);", element);
    }
}
